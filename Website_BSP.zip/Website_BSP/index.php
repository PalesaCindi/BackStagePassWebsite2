<?php
include("./config/db.php");?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BackStagePass</title>
    <link rel="stylesheet" href="./assets/css/style.css">
</head>
<body>
    <div class="navbar">
        <a href="signup.php" class="signup">Sign Up</a>
        <a href="login.php" class="login"> Login</a>

    </div>
   
    <br>
    <br>
   
    <nav class="navigation">
        <a href="index.php">Home</a>
        <a href="about_us.php">About Us</a>
        <a href="theteam.php">The Team</a>
        <a href="event.php">Event</a>
        <a href="Artistprofile.php">Artist Profile</a>
        <a href="contactus.php">Contact Us</a>
    </nav>
</body>
<sp>


</sp>
<div class="footer-container">
    <p class="footer-left">
    51 Anso Road
    <br>
    Montana
    <br>
    Pretoria
    <br>
    Gauteng 0159
</p>

     <p class="footer-right"> Contract: 
    <br>
    Email: backsatgepass@gmail.com
    <br>
    

</p>
</div>  
</html>